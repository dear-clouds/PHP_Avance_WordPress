<html>
<head>
<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> ? blog archive <?php } ?> <?php wp_title(); ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<Meta name="Author" content="kam-oo_m">
<Meta HTTP-EQUIV="Expires" content="none">
<Meta name="Description" content="kam-oo_m">
<Meta name="Content-Language" content="French">
<meta name="generator" content="WordPress <?php bloginfo('version'); ?>" /> <!-- leave this for stats -->
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<Link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url') ?>/style.css">

<!--BEGIN NECESSARY WORDPRESS TAGS-->

<?php wp_get_archives('type=monthly&format=link'); ?>

<?php wp_head(); ?>

<!--END NECESSARY WORDPRESS TAGS-->

</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table id="Tableau_01" width="950" height="651" border="0" cellpadding="0" cellspacing="0" align="center">
	<tr>
		<td colspan="5">
			<img src="<?php bloginfo('template_url') ?>/images/Navig.jpg" usemap="#navig" width="950" height="39" alt=""></td>
	</tr>
	<tr>
		<td style="background: url('<?php bloginfo('template_url') ?>/images/index_02.jpg'); background-repeat: no-repeat;" valign="top" width="14" height="346" alt=""></td>
		<td colspan="3">
	
			
			
			
						
	<img src='<?php bloginfo('template_url') ?>/images/Header.png'  usemap='#Map' border='0'>
			
			
			
			
			
			
			
			
			</td>
			
		<td style="background: url('<?php bloginfo('template_url') ?>/images/index_04.jpg'); background-repeat: no-repeat;" valign="top"  width="12" height="346" alt=""></td>
	</tr>
	<tr>
		<td style="background: url('<?php bloginfo('template_url') ?>/images/index_05.jpg'); background-repeat: repeat-y;" valign="top" width="14" height="265" alt=""></td>
		<td style="background: url('<?php bloginfo('template_url') ?>/images/Contenu.jpg'); background-repeat: repeat-y;" valign="top" width="647" height="265" alt="" id="contenu">